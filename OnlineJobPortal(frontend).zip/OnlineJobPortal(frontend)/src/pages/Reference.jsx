import React from 'react';
import './ref.css';

function Reference() {
  // JavaScript functions go here
  function goBack(e) {
    e.preventDefault();
    window.history.back();
  }

  function toggleAnswer(container) {
    const answer = container.nextElementSibling;
    if (answer) {
      answer.style.display = answer.style.display === 'block' ? 'none' : 'block';
    }
  }
  

  return (
    <div>
      <a className="back-button" href="#" onClick={goBack}>Back</a>

      {/* First container */}
      <div className="container11">
        {/* Left Content */}
        <div className="left-content11">
          <h4>COMPLETE BLOOD COUNT; C BC</h4>
          <p>Special Instruction : No special preparation required<br />Parameters covered : 20</p>
        </div>

        {/* Right Content */}
        <div className="right-content11">
          <br /><br />
          <span className="price-icon">&#8377; 250</span><br />
          <span className="tick-icon">&#10003;</span> Home Collection
          <span className="tick-icon">&#10003;</span> Lab Test<br /><br />
          <button className="btn-left11">Add to Cart</button>
        </div>

        <div style={{ clear: 'both' }}></div>
      </div>

      {/* Second container */}
      <div className="container11">
        {/* Content */}
        <div className="content11">
          <h5>Overview</h5>
          <p>
            What is COMPLETE BLOOD COUNT; CBC?<br />
            Complete blood count (CBC) is a blood test used to evaluate your overall health & wellness and detect a wide range of disorders like anemia, infection, and leukemia. This test measures several components and features of your blood like Red blood cells which carry oxygen; White blood cells which fight infection; Hemoglobin the oxygen-carrying protein in red blood cells; Hematocrit proportion of red blood cells to the fluid component or plasma in your blood; Platelets which help with blood clotting. Abnormal increases or decreases in cell counts as revealed in a Complete blood count may indicate that you have an underlying medical condition that calls for further evaluation. This test also helps to monitor a known medical condition.
          </p>
        </div>
      </div>

      {/* Third container */}
      <div className="container11">
        {/* Content1 */}
        <div className="content1">
          <span className="icon1">⚕️</span>
          <p>Parameters:</p><br />
        </div>

        {/* List 1 */}
        <div className="list">
          <p>1. abs.basophil count</p>
          <p>2. abs.eosinophil count</p>
          <p>3. abs.lymphocyte count</p>
          <p>4. abs.monocyte count</p>
          <p>5. basophils</p>
          <p>6. eosinophils</p>
          <p>7. hemoglobin</p>
        </div>

        {/* List 2 */}
        <div className="list">
          <p>8. lymphocytes</p>
          <p>9. mch</p>
          <p>10. mchc</p>
          <p>11. mcv</p>
          <p>12. mean platelet volume</p>
          <p>13. monocytes</p>
          <p>14. neutrophils</p>
        </div>

        {/* List 3 */}
        <div className="list">
          <p>15. packed cell volume (pcv)</p>
          <p>16. platelet count</p>
          <p>17. rbc count</p>
          <p>18. red cell distribution width (rdw)</p>
          <p>19. segmented neutrophils</p>
          <p>20. total leukocyte count (tlc)</p>
        </div>
      </div>

      {/* Fourth container */}
      <div className="container2">
        {/* FAQ Header */}
        <div className="faq-header">
          <h2>Frequently Asked Questions</h2>
        </div>

        {/* FAQ Subheader */}
        <div className="faq-subheader">
          <p>Here you can find answers to all the questions related to the test.</p>
        </div>
      </div>

        {/* Fifth container */}
        <div className="container4">
          {/* FAQ Question and Answer 1 */}
          <div className="faq-question-container" onClick={e => toggleAnswer(e.target)}>
            <h3>How is the CBC test performed?</h3>
          </div>
          <div className="faq-answer">
            <p>A healthcare professional will draw a blood sample from a vein in the arm or a finger-prick or heel-prick (newborns). Unless specified by the doctor, there is no special preparation required before the test.</p>
          </div>

          {/* FAQ Question and Answer 2 */}
          <div className="faq-question-container" onClick={e => toggleAnswer(e.target)}>
            <h3>What are the risks of CBC test?</h3>
          </div>
          <div className="faq-answer">
            <p>Complete blood count (CBC) test is a safe, standard test and there are minimal risks involved such as<br /><br />- Bleeding<br />- Light-headedness<br />- Infection<br />- Bruising</p>
          </div>

          {/* FAQ Question and Answer 3 */}
          <div className="faq-question-container" onClick={e => toggleAnswer(e.target)}>
            <h3>What the results may indicate?</h3>
          </div>
          <div className="faq-answer">
            <p>A Complete blood count (CBC) is not a definitive diagnostic test. Blood cell counts that are too high or too low could signal a wide variety of conditions. Specialized tests are needed to diagnose a specific condition.<br /><br />Common terms used to describe Complete blood count (CBC) results are:<br /><br />- Anemia - not having enough healthy Red Blood Cells, Hemoglobin, and Hematocrit. Anemia causes fatigue, weakness and has many causes, including low levels of certain vitamins or iron, blood loss, or an underlying condition.<br />- Leukopenia - a low number of White Blood Cells. It is caused by a medical condition, such as an autoimmune disorder that destroys white blood cells, bone marrow problems or cancer. Certain medications also can cause white blood cell counts to drop.<br />- Leukocytosis – an increased number of White Blood Cells. It may be due to an infection or inflammation or due to a reaction to medication.<br />- Thrombocytopenia – a low number of platelets. Often a sign of an underlying medical condition or a side effect from medication.<br />- Thrombocytosis – an increased number of platelets. Often a sign of an underlying medical condition or a side effect from medication.<br />- Bleeding<br />- Light-headedness<br />- Infection<br />- Bruising</p>
          </div>
        </div>
    </div>
  );
}

export default Reference;

