import React from 'react';
import 'owl.carousel/dist/assets/owl.carousel.css'; // Import Owl Carousel CSS
import 'owl.carousel/dist/assets/owl.theme.default.css'; // Import Owl Carousel Default Theme CSS
import OwlCarousel from 'react-owl-carousel'; // Import React Owl Carousel
import './style.css';
const Home = () => {
  return (
    <div className="container-fluid p-0">
      <OwlCarousel
        className="header-carousel position-relative"
        items={1}
        loop
        nav
        dots={false}
        autoplay
        autoplayTimeout={5000}
      >
        <div className="owl-carousel-item position-relative">
          <img className="img-fluid" src="./images/homepage.jpg" alt="" />
          <div className="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" style={{ background: 'rgba(43, 57, 64, .5)' }}>
            <div className="container">
              <div className="row justify-content-start">
                <div className="col-10 col-lg-8">
                  <h1 className="display-3 text-white animated slideInDown mb-4">Every Medical Test At Your DoorStep</h1>
                  <p className="fs-5 fw-medium text-white mb-4 pb-2">Some text to describe your website Info related to the website.</p>
                  
                  <a href="/servicesection"className="secondary-button">
              Book A Test 
            </a> 
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="owl-carousel-item position-relative">
          <img className="img-fluid" src="./images/pathoimage.jpg" alt="" />
          <div className="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" style={{ background: 'rgba(43, 57, 64, .5)' }}>
            <div className="container">
              <div className="row justify-content-start">
                <div className="col-10 col-lg-8">
                  <h1 className="display-3 text-white animated slideInDown mb-4">Every Medical Test At Your DoorStep</h1>
                  <p className="fs-5 fw-medium text-white mb-4 pb-2">Some text to describe your website Info related to the website..</p>
                  <a href=""className="secondary-button">
              Book A Test 
            </a> 
                </div>
              </div>
            </div>
          </div>
        </div>
      </OwlCarousel>
      <br/>
    <div className="container-fluid bg-primary mb-5 wow fadeIn" data-wow-delay="0.1s" style={{ padding: '35px' }}>
    <div className="container">
      <div className="row g-2">
        <div className="col-md-10">
          <div className="row g-2">
            <div className="col-md-4">
              <input type="text" className="form-control border-0" placeholder="Keyword" />
            </div>
            <div className="col-md-4">
              <select className="form-select border-0">
                <option selected>Category</option>
                <option value="1">Category 1</option>
                <option value="2">Category 2</option>
                <option value="3">Category 3</option>
              </select>
            </div>
            <div className="col-md-4">
              <select className="form-select border-0">
                <option selected>Location</option>
                <option value="1">Location 1</option>
                <option value="2">Location 2</option>
                <option value="3">Location 3</option>
              </select>
            </div>
          </div>
        </div>
        <div className="col-md-2">
          <button className="btn btn-dark border-0 w-100">Search</button>
        </div>
      </div>
    </div>
  </div>
  </div>
  );
};

export default Home;

