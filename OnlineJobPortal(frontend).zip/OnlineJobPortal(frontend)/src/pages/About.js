import React from 'react';
import './style.css';
import './bootstrap.min.css';
import Team from './Team';
const About = () => {
    return (
      <div className="container-xxl py-5">
        <div className="container">
          <div className="row g-5 align-items-center">
            <div className="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
              <div className="row g-0 about-bg rounded overflow-hidden">
                <div className="col-6 text-start">
                  <img className="img-fluid w-100" src="./images/patho1.jpg" alt="" />
                </div>
                <div className="col-6 text-start">
                  <img className="img-fluid" src="./images/patho2.jpg" style={{ width: '85%', marginTop: '15%' }} alt="" />
                </div>
                <div className="col-6 text-end">
                  <img className="img-fluid" src="./images/patho3.jpg" style={{ width: '85%' }} alt="" />
                </div>
                <div className="col-6 text-end">
                  <img className="img-fluid w-100" src="./images/patho4.png" alt="" />
                </div>
              </div>
            </div>
            <div className="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
              <h1 className="mb-4">Revolutionizing Your Healthcare Experience: Seamless Diagnostics Delivered by PathoLab at Your Doorstep</h1>
              <p className="mb-4">Experience the pinnacle of convenience with PathoLab's exceptional patho services right in the comfort of your home. Our commitment to quality healthcare transcends boundaries, offering you the ease of accessing accurate diagnostic reports without leaving your doorstep. With a growing community of over 25,000 satisfied individuals who have chosen us, we take pride in being a trusted partner in your wellness journey. From timely sample collection to prompt report delivery, we streamline the process, saving you time and effort. Gain peace of mind as our experienced professionals ensure reliable results while you focus on what truly matters. Welcome to a new era of health management with PathoLab at Your Doorstep.</p>
              <p><i className="fa fa-check text-primary me-3"></i>Maintained Privacy: Data Privacy</p>
              <p><i className="fa fa-check text-primary me-3"></i>Your Health Our Priority</p>
             
              <a className="btn btn-primary py-3 px-5 mt-3" href="">Read More</a>
            </div>
          </div>
          <Team/>
        </div>
        
      </div>
    );
  };
  
  export default About;
  