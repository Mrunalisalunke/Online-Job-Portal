import React from 'react';
import './cards.css';

const ServiceSection = () => {
  return (
    <div className="pt-5 pb-5">
      <div className="container">
        <div className="row">
          <div className="section-head col-sm-12">
            <h4><span>Book Test At Home</span></h4>
            <p>
              "Conveniently book a test at home and skip the hassle of traveling. Our service brings professional healthcare to your doorstep, ensuring accurate results in a comfortable and safe environment. Schedule online, choose from a range of tests, and have a skilled technician collect samples from the comfort of your home."
            </p>
          </div>
          <div className="col-lg-4 col-sm-6">
            <div className="item10">
              <span className="icon">
                <img src="./icons/icons/blood-test.png" alt="Blood Icon" />
              </span>
              <h6>COMPLETE BLOOD COUNT; CBC</h6><br />
              <p>
                Also Known as Complete Blood Picture<br />
                Special Instruction : None<br />
                Parameters covered : 20
              </p>
              <br />
              <button className="btn-left10">Add to cart</button>
              <span className="price-right10">250</span>
              <a className="more-info10" href="/reference">Know more</a>
            </div>
          </div>
          
          <div className="col-lg-4 col-sm-6">
            <div className="item10">
              <span className="icon">
                <img src="./icons/icons/glucose-meter.png" alt="Blood Icon" />
              </span>
              <h6>GLUCOSE, FASTING (F) AND POST MEAL (PP)</h6><br />
              <p>
              Also Known as FBS, Fasting Blood Sugar, FBG <br />
                Special Instruction : 8 hrs mandetory fasting.<br />
                Parameters covered : 2
              </p>
              <br />
              <button className="btn-left10">Add to cart</button>
              <span className="price-right10">120</span>
              <a className="more-info10" href="/ref">Know more</a>
            </div>
          </div>
          <div className="col-lg-4 col-sm-6">
            <div className="item10">
              <span className="icon">
                <img src="./icons/icons/dark-urine.png" alt="Blood Icon" />
              </span>
              <h6>URINE EXAMINATION, ROUTINE; URINE, R/E</h6><br />
              <p>
              Also Known as Urine Routine, Urine R/M.
                <br />Special Instruction : First morning urine sample.
                <br />
                Parameters covered : 16
              </p><br />
              <button className="btn-left10">Add to cart</button>
              <span className="price-right10">220</span>
              <a className="more-info10" href="/ref">Know more</a>
            </div>
          </div>
          <div className="col-lg-4 col-sm-6">
            <div className="item10">
              <span className="icon">
                <img src="./icons/icons/cholesterol.png" alt="Blood Icon" />
              </span>
              <h6>LIPID PROFILE, BASIC</h6>
              <p>
                Also Known as Serum Lipid Profile<br />
                Special Instruction : Duly filled ASCVD form is mandatory.<br />
                Parameters covered : 6
              </p><br />
              <button class="btn-left10">Add to cart</button>
                <span class="price-right10">950</span>
                <a href="/reference" className="more-info10">Know more</a>
            </div>
          </div>
          <div className="col-lg-4 col-sm-6">
            <div className="item10">
              <span className="icon">
                <img src="./icons/icons/thyroid.png" alt="Blood Icon" />
              </span>
              <h6>THYROID PROFILE, TOTAL</h6>
              <p>
                Also Known as Thyroid Stimulating Hormone Total t3 Total t4, Serum Thyroid<br />
                Special Instruction : None <br />
                Parameters covered : 6
              </p><br />
              <button class="btn-left10">Add to cart</button>
                <span class="price-right10">870</span>
              <a className="more-info10" href="/ref">Know more</a>
            </div>
          </div>
          <div className="col-lg-4 col-sm-6">
            <div className="item10">
              <span className="icon">
                <img src="./icons/icons/kidneys.png" alt="Blood Icon" />
              </span>
              <h6>KIDNEY PANEL; KFT</h6>
              <p>
                Also Known as Kidney Function Test, Kidney Profile, KFT<br />
                Special Instruction : None <br />
                Parameters covered : 6
              </p><br />
              <button class="btn-left10">Add to cart</button>
                <span class="price-right10">710</span>
              <a className="more-info10" href="/ref">Know more</a>
            </div>
          </div>
          <div className="col-lg-4 col-sm-6">
            <div className="item10">
              <span className="icon">
                <img src="./icons/icons/kidneys2.png" alt="Blood Icon" />
              </span>
              <h6>CREATININE, SERUM</h6>
              <p>
                Also Known as Serum Creatinine, Creatinine level, s.creatinine<br />
                Special Instruction : None.<br /> 
                Parameters covered : 6
              </p><br />
              <button class="btn-left10">Add to cart</button>
                <span class="price-right10">1720</span>
              <a className="more-info10" href="/ref">Know more</a>
            </div>
          </div>
          <div className="col-lg-4 col-sm-6">
            <div className="item10">
              <span className="icon">
                <img src="./icons/icons/vitamin-b12.png" alt="Blood Icon" />
              </span>
              <h6>VITAMIN B12; CYANOCOBALAMIN</h6>
              <p>
                Also Known as Cyanocobalaomin, Methylocobalamin, VIT B12<br />
                Special Instruction : Overnight fasting is preferred. 
                Parameters covered : 1
              </p><br />
              <button class="btn-left10">Add to cart</button>
                <span class="price-right10">1000</span>
              <a className="more-info10" href="/ref">Know more</a>
            </div>
          </div>
          <div className="col-lg-4 col-sm-6">
            <div className="item10">
              <span className="icon">
                <img src="./icons/icons/vitamin-d.png" alt="Blood Icon" />
              </span>
              <h6>VITAMIN D 25 - HYDROXY</h6>
              <p>
                Also Known as 25-Hydroxy Cholecalciferol, VITAMIN D (25-OH)<br />
                Special Instruction : None <br />
                Parameters covered : 4
              </p><br />
              <button class="btn-left10">Add to cart</button>
                <span class="price-right10">1370</span>
              <a className="more-info10" href="/ref">Know more</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceSection;

